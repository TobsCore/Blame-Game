package application.logic;

import java.util.ArrayList;

import application.logic.api.Info;
import application.logic.api.Model;
import application.logic.api.Observer;

public abstract class ModelImpl implements Model {

	private ArrayList<Observer<Info>> observers;
	
	public ModelImpl() {}
	
	public void detach() {}
	
	public void attach() {}
	
	
}
