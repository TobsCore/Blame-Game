package application.logic;

import application.logic.api.Model;



public class APIFactoryImpl implements APIFactory {

	/**
	 * @directed true
	 * @link composition
	 * @supplierRole model
	 */
	private ModelImpl model;
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 */
	
	private static APIFactoryImpl factory;
	
	private APIFactoryImpl() {
		
	}
	
	public static APIFactory makeFactory() {
		if (APIFactoryImpl.factory == null) {
			APIFactoryImpl.factory = new APIFactoryImpl();
		}
		return factory;
	}
	
	public Model getModel() {
		if (this.model == null) {
			this.model = new ModelImpl(this);
		}
		return this.model;
	}
}
