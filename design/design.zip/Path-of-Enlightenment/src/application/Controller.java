package application;

import application.logic.api.Info;
import application.logic.api.Observer;

public class Controller<T> implements Observer<T> {

	@Override
	public void update() {
		// TODO Auto-generated method stub
		
	}



}
