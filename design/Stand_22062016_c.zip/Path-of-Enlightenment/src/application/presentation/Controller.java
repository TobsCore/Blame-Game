package application.presentation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import application.logic.api.Model;
import application.logic.api.Observer;
import application.logic.api.State;

public class Controller implements Observer<State> {

	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole view
	 */

	private View view;
	private Model model;

	public Controller(View view, Model model) {
		this.model = model;
		model.attach(this);
		this.view = view;
	}

	public void runApplication() throws IOException {
		view.outputNewTurnCanRollDice();

		String input;
		while (true) {
			switch (model.getCurrentState()) {
			case MOVED_WS:
			case QUESTION:
			case NEW_WS_ON_PATH:
			case END_OF_TURN:
			case CAN_ROLL_DICE:
			case CAN_ROLL_AGAIN:
				input = readInput();
				model.wuerfeln();
				break;
			case CAN_SET_WISSENSSTREITER:
				input = readInput();
				if (!isInputValid(input)) {
					view.outputInvalidInput();
					continue;
				}
				model.setzeWissensstreiter(model.getWissensstreiterAufPfad().get(Integer.valueOf(input) - 1));
				break;
			default:
				throw new IllegalStateException("Unknown state: "
						+ model.getCurrentState());
			}
		}
	}

	private boolean isInputValid(String input) {
		if(input == null || input.isEmpty())
			return false;
		int wsCount = model.getWissensstreiterAufPfad().size();
		try {
			int wahl = Integer.parseInt(input);
			return wahl <= wsCount && wahl > 0;
		} catch (NumberFormatException e) {
			return false;
		}
	}

	private String readInput() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		return br.readLine();
	}

	@Override
	public void update(State currentInfo) {
		// nothing
	}
}
