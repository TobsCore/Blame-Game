package application.logic;

import application.logic.api.Model;



public class ApplicationFactory implements APIFactory {

	/**
	 * @directed true
	 * @link composition
	 * @supplierRole model
	 */
	private Application model;
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 */
	
	private static ApplicationFactory factory;
	
	private ApplicationFactory() {
		
	}
	
	public static APIFactory makeFactory() {
		if (ApplicationFactory.factory == null) {
			ApplicationFactory.factory = new ApplicationFactory();
		}
		return factory;
	}
	
	public Model getModel() {
		if (this.model == null) {
			this.model = new Application(this);
		}
		return this.model;
	}
}
