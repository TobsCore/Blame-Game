package application.logic.objects;


public class Wissensstreiter {

	private Feld aktuellePosition;
	
	public Wissensstreiter(Feld feld) {
		this.aktuellePosition = feld;
		this.aktuellePosition.setWissensstreiter(this);
	}

	public Feld getAktuellePosition() {
		return aktuellePosition;
	}

	public void setAktuellePosition(Feld aktuellePosition) {
		if(this.aktuellePosition != null)
			this.aktuellePosition.setWissensstreiter(null);
		this.aktuellePosition = aktuellePosition;
		this.aktuellePosition.setWissensstreiter(this);
	}
	
}
