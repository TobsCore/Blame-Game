package application.logic.objects;

import java.util.ArrayList;
import java.util.List;

import application.logic.objects.Feld.Feldtyp;


public class Pfad {
	private static final int ANZAHL_SPIELFELDER = 48;
	private List<Feld> felder;
	
	public Pfad() {
		felder = new ArrayList<>(ANZAHL_SPIELFELDER);
		for (int feldNummer = 0; feldNummer < ANZAHL_SPIELFELDER; feldNummer++) {
			felder.add(new Feld(Feldtyp.SPIELFELD, feldNummer));
		}
	}
	
	public List<Feld> getStartfelder(int spielerAnzahl) {
		List<Feld> startfeldListe = new ArrayList<>(spielerAnzahl);
		int quotient = ANZAHL_SPIELFELDER / spielerAnzahl;
		for (int feldNummer = 0; feldNummer < spielerAnzahl; feldNummer++) {
			startfeldListe.add(felder.get(feldNummer * quotient));
		}
		return startfeldListe;
	}
	
	public boolean isFeldFrei(int feldIndex) {
		return felder.get(feldIndex).isFrei();
	}
}
