
package application.presentation;

import application.logic.APIFactory;
import application.logic.api.Info;
import application.logic.api.Observer;
import application.logic.ModelImpl;

public class Controller<T> implements Observer<T> {
	
	
	
	

/**
* @clientNavigability NAVIGABLE
* @directed true
* @supplierRole factory
*/
	
	private APIFactory factory;
	
/**
* @clientNavigability NAVIGABLE
* @directed true
* @supplierRole view
*/
	
	private View<T> view;
	
	@Override
	public void update(Info currentInfo) {
		// TODO Auto-generated method stub
		
	}

}
