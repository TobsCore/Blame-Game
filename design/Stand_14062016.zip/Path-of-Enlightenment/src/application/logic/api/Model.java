package application.logic.api;

import application.logic.State;
import application.logic.usecase.Spielzug;

public interface Model extends Subject<State>, Spielzug {
	
	String getSpielername();
	State getCurrentState();
	
}
