package application.logic.api;

public interface Info {

}
