package application.logic.api;

public interface Subject<T> {
	
	public void detach(Observer observer);
	
	public void attach(Observer observer);

}
