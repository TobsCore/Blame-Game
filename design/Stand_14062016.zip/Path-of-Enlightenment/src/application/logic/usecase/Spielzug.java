package application.logic.usecase;

import application.logic.State;
import application.logic.objects.Wissensstreiter;

public interface Spielzug {

	State wuerfeln();

	State setzeWissensstreiter(Wissensstreiter wissensstreiter);
}
