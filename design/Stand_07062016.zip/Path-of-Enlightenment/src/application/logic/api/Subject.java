package application.logic.api;

public interface Subject<T> {
	
	public void detach(Observer<T> observer);
	
	public void attach(Observer<T> observer);
}
