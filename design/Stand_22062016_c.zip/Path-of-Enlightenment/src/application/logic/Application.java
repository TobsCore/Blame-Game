
package application.logic;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import application.logic.api.Model;
import application.logic.api.Observer;
import application.logic.api.State;
import application.logic.objects.Spiel;
import application.logic.objects.Wissensstreiter;
import application.logic.usecase.SpielzugManager;

public class Application implements Model {

	private ArrayList<Observer<State>> observers = new ArrayList<>();
	private State currentState;
	private SpielzugManager spielzugManager;
	private Spiel spiel;
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole factory
	 */
	
	private ApplicationFactory factory;

	public Application(ApplicationFactory factory) {
		this.factory = factory;
		this.spiel = new Spiel();
		this.currentState = State.CAN_ROLL_DICE;
		this.spielzugManager = new SpielzugManager(spiel);
	}
	
	@Override
	public void attach(Observer<State> observer) {
		this.observers.add(observer);
	}

	@Override
	public void detach(Observer<State> observer) {
		this.observers.remove(observer);
	}

	public State getCurrentState() {
		return currentState;
	}

	public void setCurrentState(State currentState) {
		this.currentState = currentState;
	}

	public Spiel getSpiel() {
		return spiel;
	}

	public void setSpiel(Spiel spiel) {
		this.spiel = spiel;
	}

	@Override
	public State wuerfeln() {
		this.setCurrentState(this.spielzugManager.wuerfeln());
		notifyObservers(currentState);
		
		return this.currentState;
	}

	@Override
	public State setzeWissensstreiter(Wissensstreiter wissensstreiter) {
		if(this.getCurrentState() == State.CAN_SET_WISSENSSTREITER) {
			this.setCurrentState(this.spielzugManager.setzeWissensstreiter(wissensstreiter));
		}
		notifyObservers(currentState);
		
		return this.currentState;
	}

	@Override
	public void notifyObservers(State state) {
		Iterator<Observer<State>> it = observers.iterator();
		while (it.hasNext()) {
			it.next().update(state);
		}
	}

	@Override
	public String getSpielername() {
		return this.spiel.getAktuellerSpieler().getName();
	}

	@Override
	public int getWuerfelergebnis() {
		return this.spiel.getWuerfelergebnis();
	}

	@Override
	public List<Wissensstreiter> getWissensstreiterAufPfad() {
		List<Wissensstreiter> wissensstreiterAufPfad = new ArrayList<>();
		for(Wissensstreiter wissensstreiter : this.spiel.getAktuellerSpieler().getWissensstreiter()) {
			if(!wissensstreiter.getAktuellePosition().isHeimatFeld()) {
				wissensstreiterAufPfad.add(wissensstreiter);
			}
		}
		return wissensstreiterAufPfad;
	}

	
}
