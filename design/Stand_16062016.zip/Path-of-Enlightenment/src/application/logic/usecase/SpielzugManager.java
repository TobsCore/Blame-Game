package application.logic.usecase;

import application.logic.api.State;
import application.logic.objects.Spiel;
import application.logic.objects.Wissensstreiter;

public class SpielzugManager implements Spielzug {

	private Spiel spiel;
	private int anzahlWuerfe;
	private int wuerfelErgebnis;

	public SpielzugManager(Spiel spiel) {
		this.spiel = spiel;
		anzahlWuerfe = 0;
		wuerfelErgebnis = 0;
	}

	@Override
	public State wuerfeln() {
		wuerfelErgebnis = spiel.wuerfeln();
		anzahlWuerfe++;
		if (wuerfelErgebnis < 6) {
			if (hasWissensstreiterAufPfad()) {
				anzahlWuerfe = 0;
				return State.CAN_SET_WISSENSSTREITER;
			} else {
				if (anzahlWuerfe == 3) {
					endZug();
					return State.END_OF_TURN;
				} else {
					return State.CAN_ROLL_AGAIN;
				}
			}
		} else {
			Wissensstreiter wissensstreiter = getWissensstreiterVonHeimatfeld();
			if (wissensstreiter != null) {
				if (spiel.isStartfeldFrei()) {
					wissensstreiter.setAktuellePosition(spiel
							.getAktuellerSpieler().getStartFeld());
					endZug();
					return State.NEW_WS_ON_PATH;
				} else {
					endZug();
					return State.QUESTION;
				}
			} else {
				anzahlWuerfe = 0;
				return State.CAN_SET_WISSENSSTREITER;
			}
		}
	}

	@Override
	public State setzeWissensstreiter(Wissensstreiter wissensstreiter) {
		int altePosition = wissensstreiter.getAktuellePosition().getFeldIndex();
		int neuePosition = (altePosition + wuerfelErgebnis) % spiel.getPfad().getFelderAnzahl();
		if(spiel.getPfad().isFeldFrei(neuePosition)) {
			wissensstreiter.setAktuellePosition(spiel.getPfad().getFeld(neuePosition));
			endZug();
			return State.MOVED_WS;
		} 
		endZug();
		return State.QUESTION;
	}

	private void endZug() {
		anzahlWuerfe = 0;
		this.spiel.nextSpieler();
	}

	private boolean hasWissensstreiterAufPfad() {
		for (Wissensstreiter wissensstreiter : spiel.getAktuellerSpieler()
				.getWissensstreiter()) {
			if (!wissensstreiter.getAktuellePosition().isHeimatFeld())
				return true;
		}
		return false;
	}

	private Wissensstreiter getWissensstreiterVonHeimatfeld() {
		for (Wissensstreiter wissensstreiter : spiel.getAktuellerSpieler()
				.getWissensstreiter()) {
			if (wissensstreiter.getAktuellePosition().isHeimatFeld())
				return wissensstreiter;
		}
		return null;
	}

}
