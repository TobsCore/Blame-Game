package application;

import application.logic.APIFactory;
import application.logic.ApplicationFactory;
import application.logic.api.Model;
import application.presentation.View;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		APIFactory api = ApplicationFactory.makeFactory();
		Model model = api.getModel(); 
		View view = new View(model);
		try {
			view.getController().runApplication();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
