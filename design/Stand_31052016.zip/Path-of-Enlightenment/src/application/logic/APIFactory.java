package application.logic;

import application.logic.api.Model;


public interface APIFactory {

	
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 */
	
	public static APIFactory factory = APIFactoryImpl.makeFactory();

	Model getModel();
}
