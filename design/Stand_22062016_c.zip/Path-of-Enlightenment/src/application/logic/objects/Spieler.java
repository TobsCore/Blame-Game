package application.logic.objects;

import java.util.ArrayList;
import java.util.List;

import application.logic.objects.Feld.Feldtyp;


public class Spieler {

	private static final int ANZAHL_WISSENSSTREITER = 3;
	private String name;
	private List<Wissensstreiter> wissensstreiter;
	private Feld startFeld;
	
	public Spieler(String name, Feld startFeld) {
		this.name = name;
		this.startFeld = startFeld;
		this.wissensstreiter = new ArrayList<>(ANZAHL_WISSENSSTREITER);
		for (int wissensstreiterNummer = 0; wissensstreiterNummer < ANZAHL_WISSENSSTREITER; wissensstreiterNummer++){
			wissensstreiter.add(new Wissensstreiter(new Feld(Feldtyp.HEIMATFELD, -1)));
		}
	}

	public List<Wissensstreiter> getWissensstreiter() {
		return wissensstreiter;
	}

	public void setWissensstreiter(List<Wissensstreiter> wissensstreiter) {
		this.wissensstreiter = wissensstreiter;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Feld getStartFeld() {
		return startFeld;
	}

	public void setStartFeld(Feld startFeld) {
		this.startFeld = startFeld;
	}
	
	
}
