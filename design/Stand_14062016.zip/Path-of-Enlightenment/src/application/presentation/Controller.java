package application.presentation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import application.logic.State;
import application.logic.api.Model;
import application.logic.api.Observer;

public class Controller implements Observer<State> {

	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole view
	 */

	private View view;
	private Model model;

	public Controller(View view, Model model) {
		this.model = model;
		model.attach(this);
		this.view = view;
	}

	public void runApplication() throws IOException {

		String input;
		while (true) {
			switch (model.getCurrentState()) {
			case FINISHED:
			case NEW_WS_ON_FIELD:
			case START:
				System.out.println(model.getSpielername() + " ist am Zug!");
				// keine break!
			case CAN_ROLL_DICE:
				System.out.println("Bitte drück Enter zum Würfeln!");
				input = readInput();
				model.wuerfeln();
				break;
			case CAN_SET_WISSENSSTREITER:
				input = readInput();
				if (!isInputValid(input)) {
					System.out
							.println("Die Eingabe war ungültig. Bitte gib einen zulässigen Wert ein.");
					continue;
				}
				model.setzeWissensstreiter(null);
				break;
			default:

			}
		}
	}

	private boolean isInputValid(String input) {
		return "1".equals(input);
	}

	private String readInput() throws IOException {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		return br.readLine();
	}

	@Override
	public void update(State currentInfo) {
		// TODO Auto-generated method stub

	}
}
