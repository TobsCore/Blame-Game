package application.presentation;

import application.logic.api.Info;
import application.logic.api.Observer;

public class View<T> implements Observer<T>{

	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole controller
	 */
	
	private Controller<T> controller;
	
	public View() { }

	@Override
	public void update(Info currentInfo) {
		// TODO Auto-generated method stub
		
	}
}
