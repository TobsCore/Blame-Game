package application.logic.objects;

import java.util.Random;

public class Wuerfel {
	
	private Random random = new Random();

	public int wuerfeln() {
		return random.nextInt(6) + 1;
	}

}
