package application.logic.api;

public enum Info {
	ZUG_BEGIN,
	
}
