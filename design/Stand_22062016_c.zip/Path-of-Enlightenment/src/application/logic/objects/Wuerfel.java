package application.logic.objects;

import java.util.Random;

public class Wuerfel {
	
	private Random random = new Random();
	private int augenzahl = 0;

	public int wuerfeln() {
		this.augenzahl = random.nextInt(6) + 1;
		return this.augenzahl;
	}
	
	public int getAugenzahl() {
		return this.augenzahl;
	}

}
