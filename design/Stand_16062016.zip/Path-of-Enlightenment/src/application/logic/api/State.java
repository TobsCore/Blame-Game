package application.logic.api;

public enum State {
	CAN_ROLL_DICE,
	CAN_ROLL_AGAIN,
	CAN_SET_WISSENSSTREITER,
	END_OF_TURN,
	NEW_WS_ON_PATH,
	MOVED_WS,
	QUESTION
}
