package design.sequencetoby;
public class Würfel {
}
