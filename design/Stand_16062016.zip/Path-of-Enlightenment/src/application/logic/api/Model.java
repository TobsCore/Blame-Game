package application.logic.api;

import java.util.List;

import application.logic.objects.Wissensstreiter;
import application.logic.usecase.Spielzug;

public interface Model extends Subject<State>, Spielzug {
	
	String getSpielername();
	
	State getCurrentState();
	
	int getWuerfelergebnis();
	
	List<Wissensstreiter> getWissensstreiterAufPfad();
	
}
