
package application.logic;

import java.util.ArrayList;

import application.logic.api.Info;
import application.logic.api.Model;
import application.logic.api.Observer;

public class ModelImpl implements Model {

	
	private ArrayList<Observer<Info>> observers;
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole currentInfo
	 */
	
	private Info currentInfo;
	
	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole factory
	 */
	
	private APIFactoryImpl factory;

	public ModelImpl(APIFactoryImpl factory) {
		this.factory = factory;
	}

	@Override
	public void attach(Observer<Info> observer) {
		this.observers.add(observer);
		observer.update(this.currentInfo);
	}

	@Override
	public void detach(Observer<Info> observer) {
		this.observers.remove(observer);
	}

}
