package application.logic.objects;


public class Feld {
	
	public static enum Feldtyp {
		SPIELFELD,
		HEIMATFELD
	}
	
	private Feldtyp feldtyp;
	private Wissensstreiter wissensstreiter;
	private int feldIndex;
	
	public Feld(Feldtyp feldtyp, int feldIndex) {
		this.feldtyp = feldtyp;
		this.feldIndex = feldIndex;
	}
	
	public boolean isHeimatFeld() {
		return this.feldtyp == Feldtyp.HEIMATFELD;
	}

	public Wissensstreiter getWissensstreiter() {
		return wissensstreiter;
	}

	public void setWissensstreiter(Wissensstreiter wissensstreiter) {
		this.wissensstreiter = wissensstreiter;
	}

	public boolean isFrei() {
		return wissensstreiter == null;
	}

	public int getFeldIndex() {
		return feldIndex;
	}

	public void setFeldIndex(int feldIndex) {
		this.feldIndex = feldIndex;
	}
}
