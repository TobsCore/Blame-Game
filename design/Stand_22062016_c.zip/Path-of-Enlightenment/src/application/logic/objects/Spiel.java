package application.logic.objects;

import java.util.ArrayList;
import java.util.List;

public class Spiel {

	private static final int ANZAHL_SPIELER = 3;
	private Pfad pfad;
	private List<Spieler> spieler;
	private Spieler aktuellerSpieler;
	private Wuerfel wuerfel;

	public Spiel() {
		this.pfad = new Pfad();
		initSpieler();
		this.wuerfel = new Wuerfel();
	}
	
	private void initSpieler() {
		this.spieler = new ArrayList<>(ANZAHL_SPIELER);
		List<Feld> startFelder = pfad.getStartfelder(ANZAHL_SPIELER);
		for(int spielerNummer = 0; spielerNummer < ANZAHL_SPIELER; spielerNummer++) {
			this.spieler.add(new Spieler("Spieler" + spielerNummer, startFelder.get(spielerNummer)));
		}
		this.aktuellerSpieler = spieler.get(0);
	}

	public Spieler nextSpieler() {
		int index = (spieler.indexOf(aktuellerSpieler) + 1) % spieler.size();
		
		aktuellerSpieler = spieler.get(index);
		return aktuellerSpieler;
	}
	
	public int wuerfeln() {
		return wuerfel.wuerfeln();
	}
	
	public int getWuerfelergebnis() {
		return wuerfel.getAugenzahl();
	}

	public Pfad getPfad() {
		return pfad;
	}

	public void setPfad(Pfad pfad) {
		this.pfad = pfad;
	}

	public List<Spieler> getSpieler() {
		return spieler;
	}

	public void setSpieler(List<Spieler> spieler) {
		this.spieler = spieler;
	}

	public Spieler getAktuellerSpieler() {
		return aktuellerSpieler;
	}

	public void setAktuellerSpieler(Spieler aktuellerSpieler) {
		this.aktuellerSpieler = aktuellerSpieler;
	}
	
	public boolean isStartfeldFrei() {
		return this.aktuellerSpieler.getStartFeld().isFrei();
	}

}
