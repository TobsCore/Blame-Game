package application.presentation;

import java.util.List;

import application.logic.api.Model;
import application.logic.api.Observer;
import application.logic.api.State;
import application.logic.objects.Wissensstreiter;

public class View implements Observer<State> {

	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole controller
	 */

	private Controller controller;
	private Model model;

	public View(Model model) {
		this.model = model;
		model.attach(this);
		this.controller = new Controller(this, model);
	}

	@Override
	public void update(State currentInfo) {
		if (currentInfo != null) {

			switch (currentInfo) {
			case CAN_ROLL_AGAIN:
				outputCanRollDiceAgain();
				break;
			case CAN_ROLL_DICE:
				outputNewTurnCanRollDice();
				break;
			case CAN_SET_WISSENSSTREITER:
				outputCanSetWissensstreiter();
				break;
			case NEW_WS_ON_PATH:
				outputNewWissensstreiterOnPath();
				outputEndOfTurn();
				outputNewTurnCanRollDice();
				break;
			case MOVED_WS:
				outputMovedWissensstreiter();
				outputEndOfTurn();
				outputNewTurnCanRollDice();
				break;
			case QUESTION:
				outputQuestionRound();
				outputEndOfTurn();
				outputNewTurnCanRollDice();
				break;
			case END_OF_TURN:
				outputWuerfelErgebnis();
				outputEndOfTurn();
				outputNewTurnCanRollDice();
				break;
			
			default:
				throw new IllegalStateException("Unknown state: "
						+ currentInfo);
			}
		}

	}

	private void outputMovedWissensstreiter() {
		System.out.println("Der Wissensstreiter wurde versetzt.");
	}

	private void outputEndOfTurn() {
		System.out.println("Der Zug ist zu ende.");
		System.out.println("========\n");
	}

	private void outputQuestionRound() {
		System.out.println("An dieser Stelle würde eine Fragerunde beginnen.");
		System.out.println("Not implemeneted");
	}

	private void outputNewWissensstreiterOnPath() {
		outputWuerfelErgebnis();
		System.out.println("Es wurde ein Wissensstreiter auf das Startfeld gesetzt.");
	}

	private void outputCanSetWissensstreiter() {
		outputWuerfelErgebnis();
		System.out.println("Bitte wählen sie einen der folgenden Wissensstreiter aus:");
		List<Wissensstreiter> wissensstreiterAufPfad = model.getWissensstreiterAufPfad();
		for (int i = 0; i < wissensstreiterAufPfad.size(); i++) {
			int nummer = i + 1;
			System.out.println(nummer + ") auf Feld " + wissensstreiterAufPfad.get(i).getAktuellePosition().getFeldIndex());
		}
		System.out.print("Bitte Nummer eingeben: ");
	}

	private void outputWuerfelErgebnis() {
		System.out.println("Es wurde eine " + model.getWuerfelergebnis() + " gewürfelt.");
	}

	private void outputCanRollDiceAgain() {
		outputWuerfelErgebnis();
		System.out.println("Es befinden sich alle Wissensstreiter auf dem Heimatfeld - Erneut würfeln");
		printCallToRoll();
	}

	private void printCallToRoll() {
		System.out.println("Bitte drück Enter zum Würfeln!");
	}

	public void outputNewTurnCanRollDice() {
		System.out.println("\n========");
		System.out.println(model.getSpielername() + " ist am Zug!");
		printCallToRoll();
	}

	public Controller getController() {
		return controller;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}
	
	public void outputInvalidInput() {
		System.out.print("Die Eingabe war ungültig. Bitte gib einen zulässigen Wert ein: ");
	}
}
