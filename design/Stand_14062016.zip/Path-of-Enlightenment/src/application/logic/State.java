package application.logic;

public enum State {
	CAN_ROLL_DICE,
	CAN_SET_WISSENSSTREITER,
	FINISHED,
	START,
	NEW_WS_ON_FIELD
}
