package application.presentation;

import application.logic.State;
import application.logic.api.Info;
import application.logic.api.Model;
import application.logic.api.Observer;

public class View implements Observer<State> {

	/**
	 * @clientNavigability NAVIGABLE
	 * @directed true
	 * @supplierRole controller
	 */

	private Controller controller;
	private Model model;

	public View(Model model) {
		this.model = model;
		model.attach(this);
		this.controller = new Controller(this, model);
	}

	@Override
	public void update(State currentInfo) {
		if (currentInfo != null) {

			switch (currentInfo) {
			case CAN_ROLL_DICE:
				System.out.println("Es befinden sich alle Wissensstreiter auf dem Heimatfeld - Erneut würfeln");
				break;
			case CAN_SET_WISSENSSTREITER:
				System.out.println("Bitte wählen sie einen der folgenden Wissensstreiter aus:");
				System.out.println("Liste");
			case START:
				break;
			case NEW_WS_ON_FIELD:
				System.out.println("Es wurde ein Wissensstreiter auf das Startfeld gesetzt.");
			case FINISHED:
				System.out.println("Der Zug ist beendet");
				break;
			default:
				throw new IllegalStateException("Unknown Info type: "
						+ currentInfo);
			}
		}

	}

	public Controller getController() {
		return controller;
	}

	public void setController(Controller controller) {
		this.controller = controller;
	}
}
