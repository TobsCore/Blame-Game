package application.logic;

public interface APIFactory {

	void getModel();
}
