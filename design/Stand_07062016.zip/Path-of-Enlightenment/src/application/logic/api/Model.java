package application.logic.api;

public interface Model extends Subject<Info> {

}
