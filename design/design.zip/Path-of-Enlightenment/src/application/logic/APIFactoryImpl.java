package application.logic;

import application.logic.api.Model;

public class APIFactoryImpl {

	private APIFactoryImpl factory;
	
	private APIFactoryImpl() {
		
	}
	
	public APIFactoryImpl makeFactory() {
		return factory;
	}
	
	public Model getModel() {
		return null;
	}
}
